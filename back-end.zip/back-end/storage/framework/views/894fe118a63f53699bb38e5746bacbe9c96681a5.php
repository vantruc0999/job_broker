<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail</title>
</head>
<body>
    Dear <b><?php echo e($candidate_name); ?></b>
    <?php echo $recruiter->approval_email; ?>

    <b><i>Best regard</i></b><br>      
    <?php echo $recruiter->signature; ?>

</body>
</html><?php /**PATH C:\Users\DELL\Documents\cap2\job_broker\back-end\resources\views/mail/approved.blade.php ENDPATH**/ ?>