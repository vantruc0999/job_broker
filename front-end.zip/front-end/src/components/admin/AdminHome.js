import Sidebar from "../recruiter/Sidebar"

function AdminHome(){
    return(
        <>
             <div className="page-container">
                <Sidebar/>
             </div>
        </>
    )
}
export default AdminHome