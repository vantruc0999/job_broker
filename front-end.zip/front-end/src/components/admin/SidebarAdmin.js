import "../../assets/css/adminlte.min.css";

function SidebarAdmin() {
  return <></>;
}
export default SidebarAdmin;
